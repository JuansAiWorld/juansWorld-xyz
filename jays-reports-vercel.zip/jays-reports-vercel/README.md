# Blue Jays Reports - Vercel Serverless Edition

## Architecture

This version is built for Vercel's serverless platform:

```
jays-reports-vercel/
├── api/                    # Serverless functions
│   ├── index.py           # Health check
│   ├── login.py           # Authentication
│   ├── logout.py          # Clear session
│   ├── reports.py         # List all reports
│   ├── report.py          # Single report view
│   ├── admin_generate.py  # Create new report
│   └── _lib/              # Shared utilities
│       ├── auth.py        # Password verification
│       ├── reports_db.py  # Git-based storage
│       └── template.py    # HTML rendering
├── reports/               # Stored reports (Git-backed)
│   └── 2026/
│       └── 04/
│           └── 2026-04-19-blue-jays-vs-d-backs.md
├── public/                # Static assets
│   ├── index.html         # Landing page
│   ├── login.html         # Login page
│   ├── css/
│   │   └── style.css      # Dark theme styles
│   └── js/
│       └── app.js         # Client-side logic
├── requirements.txt
└── vercel.json            # Vercel configuration
```

## Storage Strategy

Since Vercel filesystem is read-only, reports are stored in Git:

1. **Reports directory** committed to repo
2. **Admin generate** creates file → commits via GitHub API
3. **Auto-deploy** on push triggers Vercel rebuild
4. **Reports available** immediately after rebuild

Alternative: Use Vercel KV (Redis) or PlanetScale (MySQL) for database storage.

## Setup Instructions

### 1. Environment Variables

In Vercel dashboard, set:

```
SESSION_SECRET=your_random_secret_here
ADMIN_PASSWORD_HASH=pbkdf2:sha256:...(use generate_hash.py)
GITHUB_TOKEN=ghp_... (for auto-commit reports)
REPO_OWNER=JuansAiWorld
REPO_NAME=JuansAiWorld
```

### 2. Generate Admin Password Hash

```bash
python api/_lib/generate_hash.py yourpassword
# Copy output to ADMIN_PASSWORD_HASH env var
```

### 3. Deploy

```bash
vercel --prod
```

## API Endpoints

| Endpoint | Method | Auth Required | Description |
|----------|--------|---------------|-------------|
| `/api/login` | POST | No | Authenticate user |
| `/api/logout` | POST | Yes | Clear session |
| `/api/reports` | GET | Yes | List all reports |
| `/api/report?id=slug` | GET | Yes | Single report |
| `/api/admin/generate` | POST | Admin only | Create report |

## Client-Side Flow

1. User visits `/reports` → `login.html` loads (client-side routing)
2. Login form POSTs to `/api/login` → Sets HTTP-only cookie
3. Authenticated requests include session cookie
4. Reports list fetched from `/api/reports`
5. Individual report content fetched from `/api/report?id=slug`

## Security

- Session cookies are HTTP-only and secure
- Passwords hashed with PBKDF2
- CSRF protection on all state-changing routes
- Rate limiting on login attempts
