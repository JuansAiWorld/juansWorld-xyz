from flask import Flask, request, jsonify
import sys
sys.path.insert(0, '.')
from api._lib.auth import check_auth
from api._lib.reports_db import get_all_reports

app = Flask(__name__)

@app.route('/', methods=['GET'])
def list_reports():
    """List all reports (requires auth)"""
    user = check_auth()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    
    page = request.args.get('page', 1, type=int)
    opponent = request.args.get('opponent', '')
    
    reports = get_all_reports()
    
    if opponent:
        reports = [r for r in reports if opponent.lower() in r['title'].lower()]
    
    # Pagination
    per_page = 10
    total = len(reports)
    start = (page - 1) * per_page
    end = start + per_page
    paginated = reports[start:end]
    
    return jsonify({
        "reports": paginated,
        "page": page,
        "total_pages": (total + per_page - 1) // per_page,
        "total": total,
        "user": user
    })
