from flask import Flask, request, jsonify, make_response
import os
import sys
sys.path.insert(0, '.')
from api._lib.auth import check_auth
from api._lib.reports_db import get_report_by_slug

app = Flask(__name__)

@app.route('/', methods=['GET'])
def get_report():
    """Get single report by slug (requires auth)"""
    user = check_auth()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    
    slug = request.args.get('id')
    if not slug:
        return jsonify({"error": "Report ID required"}), 400
    
    report = get_report_by_slug(slug)
    if not report:
        return jsonify({"error": "Report not found"}), 404
    
    return jsonify({
        "report": report,
        "user": user
    })
