from flask import Flask, request, jsonify, make_response
import sys
sys.path.insert(0, '.')
from api._lib.auth import check_auth

app = Flask(__name__)

@app.route('/', methods=['POST'])
def logout():
    """Clear session cookie"""
    user = check_auth()
    
    response = make_response(jsonify({
        "success": True,
        "message": "Logged out successfully"
    }))
    
    response.set_cookie('session', '', expires=0)
    return response
