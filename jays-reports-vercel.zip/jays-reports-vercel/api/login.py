from flask import Flask, request, jsonify, make_response
import sys
sys.path.insert(0, '.')
from api._lib.auth import verify_password, create_session, ADMIN_PASSWORD_HASH

app = Flask(__name__)

@app.route('/', methods=['POST'])
def login():
    """Authenticate user and set session cookie"""
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400
    
    if username != 'admin':
        return jsonify({"error": "Invalid credentials"}), 401
    
    if ADMIN_PASSWORD_HASH:
        try:
            salt, stored_hash = ADMIN_PASSWORD_HASH.split(':')
            if not verify_password(password, salt, stored_hash):
                return jsonify({"error": "Invalid credentials"}), 401
        except ValueError:
            return jsonify({"error": "Server configuration error"}), 500
    else:
        if password != 'changeme123':
            return jsonify({"error": "Invalid credentials"}), 401
    
    session_token = create_session(username)
    
    response = make_response(jsonify({
        "success": True,
        "username": username
    }))
    
    response.set_cookie(
        'session',
        session_token,
        httponly=True,
        secure=True,
        samesite='Lax',
        max_age=7 * 24 * 60 * 60
    )
    
    return response
