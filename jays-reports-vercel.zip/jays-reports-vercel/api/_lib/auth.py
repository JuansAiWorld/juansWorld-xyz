# Shared authentication utilities
import os
import hashlib
import secrets
from functools import wraps
from flask import request, jsonify

# Get from environment variables
SESSION_SECRET = os.environ.get('SESSION_SECRET', secrets.token_hex(32))
ADMIN_PASSWORD_HASH = os.environ.get('ADMIN_PASSWORD_HASH', '')

def hash_password(password: str, salt: str = None):
    """Hash password with PBKDF2"""
    if salt is None:
        salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return salt, hashed.hex()

def verify_password(password: str, salt: str, hashed: str):
    """Verify password against hash"""
    _, check_hash = hash_password(password, salt)
    return check_hash == hashed

def check_auth():
    """Check if user is authenticated via session cookie"""
    session_token = request.cookies.get('session')
    if not session_token:
        return None
    
    # Simple session validation (in production, use JWT or database)
    try:
        # Decode session token (format: username:signature)
        parts = session_token.split(':')
        if len(parts) != 2:
            return None
        
        username, signature = parts
        expected = hashlib.sha256(f"{username}:{SESSION_SECRET}".encode()).hexdigest()[:32]
        
        if signature == expected:
            return username
    except:
        pass
    
    return None

def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = check_auth()
        if not user:
            return jsonify({"error": "Authentication required"}), 401
        return f(user, *args, **kwargs)
    return decorated_function

def require_admin(f):
    """Decorator to require admin role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = check_auth()
        if user != 'admin':
            return jsonify({"error": "Admin access required"}), 403
        return f(user, *args, **kwargs)
    return decorated_function

def create_session(username: str):
    """Create session token"""
    signature = hashlib.sha256(f"{username}:{SESSION_SECRET}".encode()).hexdigest()[:32]
    return f"{username}:{signature}"
