# Report storage using Git-based approach
import os
import json
from datetime import datetime
from pathlib import Path
import markdown
from markdown.extensions import fenced_code, tables

# Reports are stored in the repo under /reports
REPORTS_DIR = Path(__file__).parent.parent.parent / 'reports'

def get_all_reports():
    """Get all reports sorted by date (newest first)"""
    reports = []
    
    if not REPORTS_DIR.exists():
        return reports
    
    for report_file in REPORTS_DIR.rglob('*.md'):
        # Extract date from filepath
        rel_path = report_file.relative_to(REPORTS_DIR)
        
        # Try to get date from filename or path
        stat = report_file.stat()
        created = datetime.fromtimestamp(stat.st_mtime)
        
        # Read title from first line
        with open(report_file, 'r', encoding='utf-8') as f:
            first_line = f.readline().strip()
            title = first_line.replace('#', '').strip() if first_line.startswith('#') else report_file.stem
        
        slug = report_file.stem
        
        reports.append({
            'slug': slug,
            'title': title,
            'date': created.isoformat(),
            'date_formatted': created.strftime('%B %d, %Y'),
            'path': str(rel_path)
        })
    
    return sorted(reports, key=lambda x: x['date'], reverse=True)

def get_report_by_slug(slug: str):
    """Get a specific report by slug"""
    if not REPORTS_DIR.exists():
        return None
    
    for report_file in REPORTS_DIR.rglob('*.md'):
        if report_file.stem == slug:
            with open(report_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Convert markdown to HTML
            md = markdown.Markdown(extensions=['fenced_code', 'tables'])
            html_content = md.convert(content)
            
            return {
                'slug': slug,
                'title': report_file.stem.replace('-', ' ').title(),
                'content': content,
                'html': html_content,
                'path': str(report_file.relative_to(REPORTS_DIR))
            }
    
    return None

def get_report_slugs():
    """Get list of all report slugs for client-side filtering"""
    reports = get_all_reports()
    return [r['slug'] for r in reports]
